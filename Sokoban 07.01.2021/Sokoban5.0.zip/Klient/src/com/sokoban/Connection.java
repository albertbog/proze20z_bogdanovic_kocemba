package com.sokoban;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Connection {
    private static int port;
    private static String host;
    private static Socket serverSocket;
    static final String config_server_path="src/com/sokoban/config/DaneWyjscioweSerwera.txt";

    public void load_data()
    {
        try {
            BufferedReader bufferedReader=new BufferedReader(new FileReader(config_server_path));
            port=Integer.parseInt(bufferedReader.readLine());
            host=((bufferedReader.readLine()).split("/")[1]);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean try_to_connect()
    {
        try{
            serverSocket = new Socket(host, port);
            return true;
        } catch (UnknownHostException e) {
            System.out.println("Sorry! We could not connect!");
            return false;
        } catch (IOException exception) {
            return false;
        }
    }

    public String exchange_messages(String command)
    {
        String line = null;
        OutputStream os = null;
        try {
            serverSocket = new Socket(host, port);
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        try {
            os = serverSocket.getOutputStream();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        PrintWriter pw = new PrintWriter(os, true);
        pw.println(command);
        InputStream is = null;
        try {
            is = serverSocket.getInputStream();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        try {
            line= br.readLine();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        try {
            serverSocket.close();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        return line;
    }
}
