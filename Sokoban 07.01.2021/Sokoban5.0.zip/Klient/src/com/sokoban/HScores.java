package com.sokoban;

import java.io.*;
import java.util.*;

public class HScores {
    static ArrayList<String> list;
    static final String ranking_path="src/com/sokoban/ranking/ranking.txt";
    boolean connectionEstablished;

    public HScores(boolean connectionE)
    {
        connectionEstablished=connectionE;
    }

    public void loadRanking(){
        if(!connectionEstablished)
        {
            loadRankingFromFile();
        }
        else
        {
            loadRankingFromServer();
        }
    }

    private void loadRankingFromServer(){
        String line=AppSettingsFromServer.load_ranking();
        list=new ArrayList<>();
        String[] dd=line.split("/");
        for(int i = 0; i<dd.length; i++)
        {
            list.add(dd[i]);
        }

    }


    private void loadRankingFromFile(){
        try {
            list=new ArrayList<>();
            BufferedReader File = new BufferedReader(new FileReader(ranking_path));
            String line=File.readLine();
            do {
                list.add(line);
                line=File.readLine();
            }while(line!=null);
            File.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    private void saveScore(String name, int score){
        list.add(name + " " + score);
        list.sort(new MyComparator());
        list.remove(list.size()-1);
        saveRankingInFile();
    }

    static class MyComparator implements Comparator<String> {
        @Override
        public int compare(String o1, String o2){
            Integer a = Integer.parseInt(o1.split(" ")[1]);
            Integer b = Integer.parseInt(o2.split(" ")[1]);
            return -a.compareTo(b);
        }
    }

    private void saveRankingInFile() {
        try {
            BufferedWriter File = new BufferedWriter(new FileWriter(ranking_path));
            for (String line : list) {
                File.write(line);
                File.newLine();
            }
            File.close();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }
}

