package com.sokoban;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;


public class GameMenu extends IMenu {
    private JPanel titlePanel;
    private JLabel titleLabel;
    private String type;
    private static Boolean connectionEstablished=false;

    GameMenu(MainWindow mainWindow){
        super(mainWindow);
        titleLabel=new JLabel();
        titlePanel=new JPanel();
        initPanel();
        initButtons(new String[]{"Start", "High Score","MainMenu"});
        listenersActivate();

    }
    GameMenu(MainWindow mainWindow,String gameType){
        super(mainWindow);
        if(gameType.equals("Game") || gameType.equals("Server Game")) {
            type = gameType;
            if(gameType.equals("Server Game")) {
                JOptionPane.showMessageDialog(super.mainWindow, "Connection is checking...", "Checking connection",
                        JOptionPane.INFORMATION_MESSAGE);
                Connection connection = new Connection();
                connection.load_data();
                connectionEstablished = connection.try_to_connect();
            }
            if(gameType.equals("Server Game") && !connectionEstablished)
            {JOptionPane.showMessageDialog(super.mainWindow, "Can't establish server connection... Server Game mod changed to Offline Game mod", "Warning",
                    JOptionPane.WARNING_MESSAGE);
                type="Game";
            }
            else if(gameType.equals("Server Game") && connectionEstablished)
            {
                JOptionPane.showMessageDialog(super.mainWindow, "Welcome in Server Game mod", "Server Game mod",
                        JOptionPane.INFORMATION_MESSAGE);
                type="Server Game";
            }
            titleLabel=new JLabel();
            titlePanel=new JPanel();
            initPanel();
            initButtons(new String[]{"Start", "High Score","Main Menu"});
            listenersActivate();
        }
        else {
            MainWindow.switchMenus(MainWindow.Menus.MainMenu,mainWindow);
            System.err.println("misspelled gameType");
        }

    }

    @Override
    public void initPanel(){
        this.setLayout(new GridLayout(2,1));
        this.add(MainWindow.initializeTitlePanel(titlePanel,titleLabel,type));
        menuPanel.setLayout(new BoxLayout(menuPanel,BoxLayout.Y_AXIS));
        menuPanel.setBackground(new Color(0,153,153));
        this.add(menuPanel);

    }


    private void listenersActivate(){
        menuPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                resizeBtn();
            }
        });
        if(buttons.get(0).getText().equals("Start")) {
            AppSettings.getInstance().load(connectionEstablished);
            MainWindow.menus[MainWindow.Menus.AvatarMenu.index]=new AvatarMenu(mainWindow);
            buttons.get(0).addActionListener(e -> MainWindow.switchMenus(MainWindow.Menus.AvatarMenu,mainWindow));
        }
        if(buttons.get(1).getText().equals("High Score")) {
            HScores score=new HScores(connectionEstablished);
            score.loadRanking();
            MainWindow.menus[MainWindow.Menus.HighScoresMenu.index]=new HighScoresMenu(mainWindow);
            buttons.get(1).addActionListener(e -> MainWindow.switchMenus(MainWindow.Menus.HighScoresMenu,mainWindow));
        }
        if(buttons.get(2).getText().equals("Main Menu")) {
            connectionEstablished=false;
            buttons.get(2).addActionListener(e -> MainWindow.switchMenus(MainWindow.Menus.MainMenu,mainWindow));
        }

        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {

                MainWindow.resizeTitle(titlePanel,titleLabel);

            }
        });
    }

    @Override
    public void initButtons(String[] text) {
        super.initButtons(text);
    }


}
