package com.sokoban;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class HowToPlayMenu extends IMenu {

    private ImageIcon iconHtp;
    private Image img;
    private JLabel iconLabel;



    HowToPlayMenu(MainWindow mainWindow){
        super(mainWindow);
        initImage();
        initPanel();
        initButtons(new String[]{"Back"});
        listenersActivate();

    }

    @Override
    public void initPanel() {
        this.setLayout(new BorderLayout());
        this.add(menuPanel);
    }

    public void initImage(){
        iconLabel=new JLabel();
        iconHtp =new ImageIcon(getClass().getResource("img/sokobanHTP.png"));
        img =  iconHtp.getImage().getScaledInstance(mainWindow.getWidth(), mainWindow.getHeight(),
              Image.SCALE_SMOOTH);
       iconHtp = new ImageIcon(img);
        iconLabel=new JLabel(iconHtp);
        menuPanel.add(iconLabel);

    }


    @Override
    public void initButtons(String[] text) {
        super.initButtons(text);
       menuPanel.remove(buttons.get(0));
       this.add(buttons.get(0),BorderLayout.SOUTH);



    }
    private void resizeIcon(){
        menuPanel.remove(iconLabel);
        initImage();

    }
    private void listenersActivate(){
        buttons.get(0).addActionListener(e -> MainWindow.switchMenus(MainWindow.Menus.MainMenu,mainWindow));

        this.addComponentListener(new ComponentAdapter() {

            public void componentResized(ComponentEvent e) {
                resizeIcon();resizeBtn();
            }
        });
    }

}
