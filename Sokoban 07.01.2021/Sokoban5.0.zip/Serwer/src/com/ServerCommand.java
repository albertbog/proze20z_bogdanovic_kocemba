package com;

import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;

public class ServerCommand {

    static int numberOfLives;
    static int screenWidth;
    static int screenHeight;
    static int stepCounter;
    static int numberOfLevels;


    public static String do_command_string(String command)
    {
        String respond;
        switch (command)
        {
            case "Load_ranking":
                respond= Ranking.load_ranking();
                break;
            case "Load_levels":
                respond= Levels.load_levels();
                break;
            case "Load_config":
                respond=ConfigLoader.load_config();
                break;
                /*
            case "Exit":
                respond="Log_out";
                break;

                 */
            default:
                throw new IllegalStateException("Unexpected value: " + command);
        }
        return respond;
    }


    public static BufferedImage do_command_image(String command)
    {
        BufferedImage respond;
        switch (command)
        {
            case "Load_avatars":
                respond= Avatars.load_avatars();
                break;
            /*
            case "Load_textures":
                respond= Levels.load_levels();
                break;
            */
            default:
                throw new IllegalStateException("Unexpected value: " + command);
        }
        return respond;
    }

}
