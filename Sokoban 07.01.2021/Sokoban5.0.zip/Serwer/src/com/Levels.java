package com;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Levels {

    static final String Levels_path="Pliki\\levels";
    private static String data;

    public static String load_levels(){
        try {
            data="";
            int pet=0;
            File txtrs = new File(Levels_path);
            File[] files = txtrs.listFiles();

            for(int i=0;i<files.length;i++) {
                Scanner myReader = new Scanner(files[i]);
                while (myReader.hasNextLine()) {
                    if(i==pet) {
                        data = data + "/" + myReader.nextLine();
                    }
                    else{
                        data = data + ";";
                        pet++;
                    }
                }
                myReader.close();
            }
        }catch (FileNotFoundException e){
            System.out.println("File not found.");
            e.printStackTrace();
        }
        return data;
    }
}
