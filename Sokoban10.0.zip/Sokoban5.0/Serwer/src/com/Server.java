package com;

import java.io.*;
import java.net.*;

public class Server {
    private final int port;

    public Server()
    {
        ConfigLoader.load_port();
        port=ConfigLoader.port;
    }

    public void runServer()
    {
        try {

            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Waiting for connection!");
            while(true)
            {
                Socket socket=serverSocket.accept();
                new Thread(new MyThread(socket)).start();
            }
        }
        catch (IOException exception) {
            System.out.println("Sorry! We could not connect with server!");
        }
    }

    public int return_port()
    {
        return port;
    }
}
