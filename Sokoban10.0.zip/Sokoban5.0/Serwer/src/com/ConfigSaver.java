package com;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;

public class ConfigSaver {
    static String Data_path="DaneWyjscioweSerwera.txt";
    public ConfigSaver(int port, InetAddress localHost)
    {
        save_data_server(port, localHost);
    }

    public void save_data_server(int port, InetAddress localHost)
    {
        try {
            BufferedWriter bufferedWriter=new BufferedWriter(new FileWriter(Data_path));
            bufferedWriter.write(String.valueOf(port));
            bufferedWriter.newLine();
            bufferedWriter.write(String.valueOf(localHost));
            bufferedWriter.newLine();
            bufferedWriter.close();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

}
