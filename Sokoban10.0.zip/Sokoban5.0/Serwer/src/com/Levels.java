package com;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


public class Levels {

    static final String Levels_path = "Pliki\\levels";

    public static String load_levels(Integer numberOfLevel) {
        String data = "";
        try {
            File txtrs = new File(Levels_path);
            File[] files = txtrs.listFiles();
            for (int i = 0; i < files.length; i++) {
                if (i == numberOfLevel) {
                    Scanner myReader = null;
                    try {
                        myReader = new Scanner(files[i]);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    while (myReader.hasNextLine()) {
                        data=data+"/"+myReader.nextLine();
                    }
                    myReader.close();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
}
