package com;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class Ranking {

    static final String Ranking_path="Pliki\\Ranking.txt";
    static String list;
    static ArrayList<String> rankingList;


    public static String load_ranking()
    {
        try {
            list= "";
            BufferedReader File = new BufferedReader(new FileReader(Ranking_path));
            String line=File.readLine();
            do {
                list=list+line+"/";
                line=File.readLine();
            }while(line!=null);
            File.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        return list;
    }

    public static String save_ranking(String data)
    {
        String name=data.split("/")[0];
        Integer score=Integer.parseInt(data.split("/")[1]);
        System.out.println(name);
        String respond;
        loadRankingFromFile();
        rankingList.add(name + " " + String.valueOf(score));
        rankingList.sort(new MyComparator());
        if((rankingList.get(rankingList.size()-1))!=name + " " + String.valueOf(score)){
            respond="Huuura! Jestes najlepszy!";
        }
        else{
            respond="Niestety! Są lepsi od Ciebie. Probuj dalej!";
        }
        rankingList.remove(rankingList.size()-1);
        saveRankingInFile();
        return respond;
    }

    static class MyComparator implements Comparator<String> {
        @Override
        public int compare(String o1, String o2){
            Integer a = Integer.parseInt(o1.split(" ")[1]);
            Integer b = Integer.parseInt(o2.split(" ")[1]);
            return -a.compareTo(b);
        }
    }

    private static void saveRankingInFile() {
        try {
            BufferedWriter File = new BufferedWriter(new FileWriter(Ranking_path));
            for (String line : rankingList) {
                File.write(line);
                File.newLine();
            }
            File.close();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    private static void loadRankingFromFile(){
        try {
            rankingList=new ArrayList<>();
            BufferedReader File = new BufferedReader(new FileReader(Ranking_path));
            String line=File.readLine();
            do {
                rankingList.add(line);
                line=File.readLine();
            }while(line!=null);
            File.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }
}
