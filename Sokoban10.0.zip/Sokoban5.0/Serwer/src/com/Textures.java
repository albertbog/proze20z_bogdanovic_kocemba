package com;

import java.io.File;


public class Textures {
    private static String textures_path="Pliki/textures";

    public static String load_textures(int numberOfTexture)
    {
        String fnameNoExt = null;
        File avtrs= new File(textures_path);
        File[] files=avtrs.listFiles();

        for (Integer i = 0; i < files.length; i++){
            if(i==numberOfTexture) {
                fnameNoExt = files[i].getName().substring(0, files[i].getName().lastIndexOf("."));
            }
        }
        return textures_path+"\\"+fnameNoExt+".png";
    }
}
