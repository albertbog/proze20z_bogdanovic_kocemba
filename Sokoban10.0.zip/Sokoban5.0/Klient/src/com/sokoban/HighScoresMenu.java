package com.sokoban;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;

public class HighScoresMenu extends IMenu {

    private static final String column[]={"Rank", "Name", "Score"};
    private DefaultTableModel model=new DefaultTableModel(column,0);
    private JTable jt=new JTable(model);

    public HighScoresMenu(MainWindow mainWindow){
        super(mainWindow);
        initPanel();
        initTable(HScores.list);
        initButtons(new String[]{"Back"});
        listenersActivate();
    }

    @Override
    public void initPanel() {
        this.setBackground(new Color(0,153,153));
        this.setLayout(new GridLayout(1,0));
        menuPanel.setLayout(new GridLayout(1,0));
        menuPanel.setBackground(new Color(0,153,153));
    }

    @Override
    public void initButtons(String[] text){
        super.initButtons(text);
    }

    public void initTable(ArrayList<String> list){
        for(int i=0;i<list.size();i=i+1)
        {
            model.addRow(new String[]{String.valueOf(i+1), list.get(i).split(" ")[0], list.get(i).split(" ")[1]});
        }
        setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        setLayout(new BorderLayout(5,5));
        add(new JScrollPane(jt), BorderLayout.CENTER);
        add(menuPanel, BorderLayout.PAGE_END);
    }

    private void listenersActivate(){
        menuPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                resizeBtn();
            }
        });
        if(buttons.get(0).getText().equals("Back")) {
            buttons.get(0).addActionListener(e -> MainWindow.switchMenus(MainWindow.Menus.GameMenu,mainWindow));
        }
    }
}

