package com.sokoban;

public class AppSettingsFromServer {
    public static String load_ranking(){
        return new Connection().exchange_messages("Load_ranking");
    }
    public static String load_levels(Integer level_number){return new Connection().exchange_messages("Load_levels"+"!"+level_number); }
    public static String load_config(){return new Connection().exchange_messages("Load_config");}
    public static byte[] load_avatars(Integer avatar_number){return new Connection().exchange_messages_avatars("Load_avatars"+"!"+avatar_number);}
    public static byte[] load_textures(Integer texture_number){return new Connection().exchange_messages_avatars("Load_textures"+"!"+texture_number);}
    public static String save_ranking(String data) {return new Connection().exchange_messages(data);}
}
