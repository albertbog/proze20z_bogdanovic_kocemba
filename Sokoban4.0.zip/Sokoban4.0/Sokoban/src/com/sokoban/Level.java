package com.sokoban;


import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.Point2D;
import java.awt.image.BufferStrategy;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Level  {
    public int nRows;
    public int nColuns;
    private ArrayList<String> map;

    /** Liczba kroków gracza */
    int score;
    /** wszystkie pudła zostały umieszczone */
    boolean hasWon = false;
    /** informuje czy gra została zatrzymana */
    boolean isPaused=false;
    /** obiekt slużący do animacji */
     BufferStrategy bs = null;
     /***/


    Level(ArrayList<String> map){
        this.map=map;
        nRows=map.size();
        String str=Collections.max(map, Comparator.comparing(String::length));
        nColuns=str.length();
    }
    public ArrayList<String> getMap(){
        return map;
    }


    /**
     * W zaleznosci od tego czy serwer jest osiagalny wczytuje pliki konfiguracyjne z serwera lub z plikow lokalnych
     * @param levelIndex numer poziomu ktory ma zostac narysowany
     */
    Level(int levelIndex) throws IOException {
       // if(!Client.isOffline) PropertiesLoader.loadLevelConfigsFromServer(levelIndex);
       // if(Client.isOffline) PropertiesLoader.loadLevelConfigs(levelIndex);
        //fuel = PropertiesLoader.fuelAmount;
        //x = PropertiesLoader.startPoint;
    }

    /**
     * Pauzuje gre poprzez nadanie zmiennej isPaused wartosci true
     */
    public void pause() {
        isPaused = true;
    }
    /**
     * Wznawia gre poprzez nadanie zmiennej isPaused wartosci false
     */
    public void resume() {
        isPaused = false;
    }


}

class TAdapter extends KeyAdapter {


    private final int LEFT_COLLISION = 1;
    private final int RIGHT_COLLISION = 2;
    private final int TOP_COLLISION = 3;
    private final int BOTTOM_COLLISION = 4;
    private Drawer.Board board;
    Level level;

    TAdapter(Drawer.Board board,Level level){this.board=board; this.level=level;}

    @Override
    public void keyPressed(KeyEvent e) {

        if (level.hasWon) {
            return;
        }

        int key = e.getKeyCode();


                switch (key) {

            case KeyEvent.VK_LEFT:

                if (checkWallCollision(this.board.player,
                        LEFT_COLLISION)) {
                    return;
                }

                if (checkBagCollision(LEFT_COLLISION)) {
                    return;
                }

                board.clearMovable(board.player,board.getGraphics());
                AppSettings.stepsCounter++;
                this.board.player.move(-1, 0);
                board.repaintMovable( board.player,board.getGraphics());

                break;

            case KeyEvent.VK_RIGHT:

                if (checkWallCollision(this.board.player,
                        RIGHT_COLLISION)) {
                    return;
                }

                if (checkBagCollision(RIGHT_COLLISION)) {
                    return;
                }
                board.clearMovable(board.player,board.getGraphics());
                AppSettings.stepsCounter++;
                this.board.player.move(1, 0);
                board.repaintMovable( board.player,board.getGraphics());

                break;

            case KeyEvent.VK_UP:

                if (checkWallCollision(board.player, TOP_COLLISION)) {
                    return;
                }

                if (checkBagCollision(TOP_COLLISION)) {
                    return;
                }
                board.clearMovable(board.player,board.getGraphics());
                AppSettings.stepsCounter++;
                this.board.player.move(0, -1);
                board.repaintMovable( board.player,board.getGraphics());

                break;

            case KeyEvent.VK_DOWN:

                if (checkWallCollision(this.board.player, BOTTOM_COLLISION)) {
                    return;
                }

                if (checkBagCollision(BOTTOM_COLLISION)) {
                    return;
                }
                board.clearMovable(board.player,board.getGraphics());
                AppSettings.stepsCounter++;
                this.board.player.move(0, 1);
                board.repaintMovable( this.board.player,board.getGraphics());

                break;

            case KeyEvent.VK_R:
                board.getGraphics().clearRect(0,0,board.getWidth(),board.getHeight());
                restartLevel();
                AppSettings.stepsCounter=0;
                Sokoban.restartsCounter++;

                break;

            default:
                break;
        }
    }

    private boolean checkWallCollision(Drawer.BoardObject actor, int type) {

        switch (type) {

            case LEFT_COLLISION:

                for (int i = 0; i < board.walls.size(); i++) {

                    Drawer.BoardObject wall = board.walls.get(i);

                    if (actor.isLeftCollision(wall)) {

                        return true;
                    }
                }

                return false;

            case RIGHT_COLLISION:

                for (int i = 0; i < board.walls.size(); i++) {

                    Drawer.BoardObject wall = board.walls.get(i);

                    if (actor.isRightCollision(wall)) {
                        return true;
                    }
                }

                return false;

            case TOP_COLLISION:

                for (int i = 0; i < board.walls.size(); i++) {

                    Drawer.BoardObject wall = board.walls.get(i);

                    if (actor.isTopCollision(wall)) {

                        return true;
                    }
                }

                return false;

            case BOTTOM_COLLISION:

                for (int i = 0; i < board.walls.size(); i++) {

                    Drawer.BoardObject wall = board.walls.get(i);

                    if (actor.isBottomCollision(wall)) {

                        return true;
                    }
                }

                return false;

            default:
                break;
        }

        return false;
    }

    private boolean checkBagCollision(int type) {


               switch (type) {

            case LEFT_COLLISION:

                for (int i = 0; i < board.boxes.size(); i++) {

                    Drawer.BoardObject box = board.boxes.get(i);

                    if (board.player.isLeftCollision(box)) {

                        for (int j = 0; j <board.boxes.size(); j++) {

                            Drawer.BoardObject item = board.boxes.get(j);

                            if (!box.equals(item)) {

                                if (box.isLeftCollision(item)) {
                                    return true;
                                }
                            }

                            if (checkWallCollision(box, LEFT_COLLISION)) {
                                return true;
                            }
                        }
                        board.clearMovable(box,board.getGraphics());
                        box.move(-1, 0);
                        board.repaintMovable( box,board.getGraphics());
                        isCompleted();
                    }
                }

                return false;

            case RIGHT_COLLISION:

                for (int i = 0; i < board.boxes.size(); i++) {

                    Drawer.BoardObject box  = board.boxes.get(i);
                    Drawer.BoardObject prev = box;

                    if (board.player.isRightCollision(box)) {

                        for (int j = 0; j < board.boxes.size(); j++) {

                            Drawer.BoardObject item = board.boxes.get(j);

                            if (!box.equals(item)) {

                                if (box.isRightCollision(item)) {
                                    return true;
                                }
                            }

                            if (checkWallCollision(box, RIGHT_COLLISION)) {
                                return true;
                            }
                        }
                        board.clearMovable(box,board.getGraphics());
                        box.move(1, 0);
                        board.repaintMovable( box,board.getGraphics());
                        isCompleted();
                    }
                }
                return false;

            case TOP_COLLISION:

                for (int i = 0; i < board.boxes.size(); i++) {

                    Drawer.BoardObject box = board.boxes.get(i);
                    Drawer.BoardObject prev = box;

                    if (board.player.isTopCollision(box)) {

                        for (int j = 0; j < board.boxes.size(); j++) {

                            Drawer.BoardObject item = board.boxes.get(j);

                            if (!box.equals(item)) {

                                if (box.isTopCollision(item)) {
                                    return true;
                                }
                            }

                            if (checkWallCollision(box, TOP_COLLISION)) {
                                return true;
                            }
                        }
                        board.clearMovable(box,board.getGraphics());
                        box.move(0, -1);
                        board.repaintMovable( box,board.getGraphics());
                        isCompleted();
                    }
                }

                return false;

            case BOTTOM_COLLISION:

                for (int i = 0; i < board.boxes.size(); i++) {

                    Drawer.BoardObject box = board.boxes.get(i);
                    Drawer.BoardObject prev = box;

                    if (board.player.isBottomCollision(box)) {

                        for (int j = 0; j < board.boxes.size(); j++) {

                            Drawer.BoardObject item = board.boxes.get(j);

                            if (!box.equals(item)) {

                                if (box.isBottomCollision(item)) {
                                    return true;
                                }
                            }

                            if (checkWallCollision(box,BOTTOM_COLLISION)) {

                                return true;
                            }
                        }
                        board.clearMovable(box,board.getGraphics());
                        box.move(0, 1);
                        board.repaintMovable( box,board.getGraphics());
                        isCompleted();
                    }
                }

                break;

            default:
                break;
        }

        return false;
    }

    public void isCompleted() {

        int nOfBags = board.boxes.size();
        int finishedBags = 0;

        for (int i = 0; i < nOfBags; i++) {

            Drawer.BoardObject box = board.boxes.get(i);

            for (int j = 0; j < nOfBags; j++) {

                Drawer.BoardObject target =  board.targets.get(j);

                if (box.row == target.row && box.column == target.column) {

                    finishedBags += 1;
                }
            }
        }

        if (finishedBags == nOfBags) {

            System.out.println("Congrats\n");
            level.hasWon = true;
            Sokoban.allSteps=Sokoban.allSteps+AppSettings.stepsCounter;
            Sokoban.numOfPassedLevels++;
            AppSettings.stepsCounter=-1;
            Sokoban.currentLevel++;
           // repaint();
        }
    }

    private void restartLevel() {

        board.clearAll();
        board.initWorld();
        board.updateWorld(board.getGraphics());

        if (level.hasWon) {
            level.hasWon = false;
        }
    }

}

