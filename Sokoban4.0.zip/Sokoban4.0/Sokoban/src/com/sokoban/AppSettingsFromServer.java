package com.sokoban;

public class AppSettingsFromServer {
    public static String load_ranking(){
        return new Connection().exchange_messages("Load_ranking");
    }
    public static String load_levels(){ return new Connection().exchange_messages("Load_levels"); }
    public static String load_config(){return new Connection().exchange_messages("Load_config");}
}
