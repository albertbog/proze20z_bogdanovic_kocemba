package com.sokoban;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.GridBagConstraints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TimerTask;

public class Drawer {
    private boolean textureIsLoad = false;
    private final MainWindow mainW;
    Level level;
    Board board;
    Sokoban soko;


    Drawer(Sokoban soko,MainWindow mainWindow, Level lvl) {
        this.mainW = mainWindow;
        this.level= lvl;
        this.soko=soko;
    }

    public JPanel draw() {
        return draw_grid();
    }



    public BoardBase draw_grid() {
        BoardBase boardBase = new BoardBase();
        board=new Board();
        boardBase.add(board);
        return boardBase;
    }


    class Board extends Canvas  {

        int width, height, rows, columns;
        ArrayList<BoardObject> walls;
        ArrayList<BoardObject> boxes;
        ArrayList<BoardObject> targets;
        BoardObject player;


        Board() {
            setSize(width = (level.nColuns/ level.nRows)*mainW.getWidth()/2, height = (level.nColuns/ level.nRows)*mainW.getHeight()/2);
            rows = level.nRows;
            columns = level.nColuns;
            initWorld();
            addKeyListener(new TAdapter(this,level));
        }

        @Override public Dimension getPreferredSize() {
            System.out.println("Wywolano getPreferredSize");
            return new Dimension((level.nColuns/ level.nRows)*mainW.getWidth()/2, (level.nColuns/ level.nRows)*mainW.getHeight()/2);
        }

        @Override public void addNotify() {
            super.addNotify();
            createBufferStrategy(3);
            level.bs = getBufferStrategy();
        }

        @Override
        public void paint(Graphics g) {
            super.paint(g);
            updateWorld(g);
            int k;
            width = getSize().width;
            height = getSize().height;
        }


        public void initWorld() {

            walls = new ArrayList<>();
            boxes = new ArrayList<>();
            targets = new ArrayList<>();

            for (int r = 0; r < rows; r++)
                for (int c=0; c < columns; c++) {

                    char item = level.getMap().get(r).charAt(c);

                    switch (item) {

                        case '#':
                            walls.add(new BoardObject(AppSettings.getInstance().getLocalTexture(AppSettings.Textures.Wall),
                                    new Point2D.Float(c*getWidth()/columns,r*getHeight()/rows),AppSettings.Textures.Wall.name(),r,c));
                            break;

                        case '$':
                            boxes.add(new BoardObject(AppSettings.getInstance().getLocalTexture(AppSettings.Textures.Box1),
                                    new Point2D.Float(c*getWidth()/columns,r*getHeight()/rows),AppSettings.Textures.Box1.name(),r,c));
                            break;

                        case '.':
                            targets.add(new BoardObject(AppSettings.getInstance().getLocalTexture(AppSettings.Textures.Target),
                                    new Point2D.Float(c*getWidth()/columns,r*getHeight()/rows),AppSettings.Textures.Target.name(),r,c));
                            break;

                        case '@':
                            player=new BoardObject(AppSettings.getInstance().getLocalAvatar(AppSettings.Avatars.Santa),
                                    new Point2D.Float(c*getWidth()/columns,r*getHeight()/rows),AppSettings.Avatars.Santa.name(),r,c);

                            break;

                        default:
                            break;
                    }
                }


        }

        public void updateWorld(Graphics g) {
            ArrayList<BoardObject> world = new ArrayList<>();
            world.addAll(walls);
            world.addAll(targets);
            world.addAll(boxes);
            world.add(player);


            for (int i = 0; i < world.size(); i++) {

                BoardObject item = world.get(i);
                    item.point2D = new Point2D.Float(item.column * getWidth() / columns, item.row * getHeight() / rows);
                    g.drawImage(resize(item.image, getWidth() / columns, getHeight() / rows), (int) item.point2D.getX(), (int) item.point2D.getY(), this);

            }

        }
        public void clearMovable(BoardObject previous, Graphics g){
            g.clearRect((int)previous.point2D.getX(),(int)previous.point2D.getY(),this.getWidth()/columns,this.getHeight()/rows);
            for(int i=0;i<targets.size();i++)
            { if((int)previous.row==targets.get(i).row &&(int)previous.column==targets.get(i).column)
            {
                g.drawImage(resize(targets.get(i).image, getWidth() / columns, getHeight() / rows), (int) previous.point2D.getX(), (int) previous.point2D.getY(), this);
            }}



        }
        public void repaintMovable(BoardObject obj,Graphics g)  {
            g.drawImage(resize(obj.image, getWidth() / columns, getHeight() / rows), (int) obj.point2D.getX(), (int) obj.point2D.getY(), this);
            if(level.hasWon)
            {
                JOptionPane.showMessageDialog(this, "move to the next level","Congrats",1);
                soko.removeAll();
                soko.menuPanel.removeAll();
                soko.loadNextLevel();
            }
        }
        public Image resize(BufferedImage img, int newW, int newH) {
            Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
            return tmp;
        }
        public void clearAll(){

           walls.clear();
           boxes.clear();
           targets.clear();
        }

    }


    class BoardBase extends JPanel {


        @Override
        public Dimension getMinimumSize() {
            return new Dimension((level.nColuns/ level.nRows)*mainW.getWidth()/2,(level.nColuns/ level.nRows)*mainW.getHeight()/2);
        }

        @Override
        public Dimension getMaximumSize() {
            return new Dimension((level.nColuns/ level.nRows)*mainW.getWidth()/2,(level.nColuns/ level.nRows)*mainW.getHeight()/2);
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension((level.nColuns/ level.nRows)*mainW.getWidth()/2,(level.nColuns/ level.nRows)*mainW.getHeight()/2);
        }

        @Override
        public void paintComponent(Graphics g) {

        }
    }
    class BoardObject{
        BufferedImage image;
        Point2D point2D;
        int row;
        int column;
        String type;

        BoardObject(BufferedImage a, Point2D b,String c, int row, int column)
        {
            image=a;
            point2D=b;
            type=c;
            this.row=row;
            this.column=column;

        }
        public void move (int x,int y){
            this.point2D = new Point2D.Double((x*board.width/board.columns)+point2D.getX(), (y*board.height/board.rows)+point2D.getY());
            column=column+x;
            row=row+y;
        }

        public boolean isLeftCollision(BoardObject obj) {

            return this.column - 1 == obj.column && this.row == obj.row;
        }

        public boolean isRightCollision(BoardObject obj) {

            return this.column + 1 == obj.column && this.row == obj.row;
        }

        public boolean isTopCollision(BoardObject obj) {

            return this.row - 1 == obj.row && this.column == obj.column;
        }

        public boolean isBottomCollision(BoardObject obj) {

            return this.row + 1 == obj.row && this.column == obj.column;
        }


    }


}


