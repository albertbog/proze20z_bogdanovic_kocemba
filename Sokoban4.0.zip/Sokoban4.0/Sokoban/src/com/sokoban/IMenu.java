package com.sokoban;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class IMenu extends JPanel {
    protected ArrayList<JButton> buttons;
    protected JPanel menuPanel;
    protected MainWindow mainWindow;



    public IMenu(MainWindow mainWindow) {
        this.mainWindow=mainWindow;
        menuPanel= new JPanel();
        buttons=new ArrayList<>();
    }

    public void initPanel(){}
    public void initButtons(String[] text){

        for (String s : text) {
            JButton button = new JButton(s);
            button.setAlignmentX(CENTER_ALIGNMENT);
            button.setMaximumSize(new Dimension(menuPanel.getWidth() / 2, menuPanel.getHeight() / 2));
            buttons.add(button);
            menuPanel.add(button);

        }
        menuPanel.revalidate();
    }
    public void resizeBtn(){

        for(JButton button:buttons)
        {
            button.setMaximumSize(new Dimension(this.getWidth()/2,this.getHeight()/2));
        }
        menuPanel.revalidate();
    }

}
