package com.sokoban;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class Sokoban extends IMenu  {

    /** Informuje czy gra jest zapauzowana, true - zapauzowana */
    private boolean pauseButtonPressed = false;
    /** Przechowuje numer obecnego poziomu */
    public static int currentLevel=0;
    /** Przechowuje liczbe pozostalych żyć */
    private int numberOfLives=5;
    /**  */
    public static  int numOfPassedLevels=0;
    /** */
    public static int restartsCounter=0;
    /** */
    public static int allSteps=0;
    /** */
    private int usedMagnets;
    /** Przechowuje nick gracza */
    public static String nick;
    /** Przechowuje wynik gracza w trakcie rozgrywki*/
    private int score;
    /**obiekt pomocniczy odpowiedzialny za tworzenie planszy*/
    private Drawer drawer;
    private Level lvl;
    /***/

    JPanel info;
    private JLabel steps;
    private JLabel lifes;
    public int stepsCounter=AppSettings.stepsCounter;
    public int lifesCounter=AppSettings.numberOfLives;

    Sokoban(MainWindow w){
        super(w);

        initButtons(new String[]{"Pause", "Main Menu"});
        initPanel();


    }
    @Override
    public void initPanel(){
        lvl = AppSettings.getInstance().getAvailableLevel(currentLevel);
        drawer= new Drawer(this,mainWindow,lvl );
        this.setLayout(new BorderLayout());
        Box box = new Box(BoxLayout.Y_AXIS);
        box.setAlignmentX(JComponent.CENTER_ALIGNMENT);
        box.add(Box.createVerticalGlue());
        box.add(drawer.draw());
        box.add(Box.createVerticalGlue());
        drawer.board.setFocusable(true);
        add(box);
        menuPanel.setLayout(new GridLayout(5,1));
        menuPanel.setBackground(new Color(0,153,153));
        listenersActivate();
        info = new JPanel(new GridLayout(3,1));
        steps = new JLabel("Steps: "+AppSettings.stepsCounter);
        lifes=new JLabel("Lifes: "+lifesCounter);
        info.add(steps);info.add(lifes);
        menuPanel.add(info);
        info.setBackground(new Color(0,153,153));
        add(menuPanel,BorderLayout.EAST);
        this.setBackground(new Color(0,153,153));

    }
    @Override
    public void initButtons(String[] text) {
    super.initButtons(text);
    }
    private void listenersActivate(){
        this.addComponentListener(new ComponentAdapter() {

            public void componentResized(ComponentEvent e) {
                resizeBtn();
                menuPanel.setPreferredSize(new Dimension(mainWindow.getWidth()/7,mainWindow.getHeight()));
            }
        });

        drawer.board.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                steps.setText("Steps: "+AppSettings.stepsCounter);
                info.repaint();
            }
        });
        buttons.get(0).addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(buttons.get(0).getText()=="Pause")
                {lvl.pause();
                buttons.get(0).setText("Resume");
                drawer.board.setFocusable(false);
                System.out.println("isPaused\n");}
                else{
                    buttons.get(0).setText("Pause");
                    drawer.board.setFocusable(true);
                    drawer.board.requestFocus();
                    lvl.resume();
                }

            }
        });
        buttons.get(1).addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                    MainWindow.menus[MainWindow.Menus.MainMenu.index]=new MainMenu(mainWindow);
                    MainWindow.switchMenus(MainWindow.Menus.GameMenu,mainWindow);
                    //clearData();
            }
        });



    }

    /**
     * Wczytuje kolejny poziom, jesli gracz dotarl do konca wyswietla menu z koncowym wynikiem
     */
    public void loadNextLevel() {

        if (currentLevel <= AppSettings.numberOfLevels) {
            initButtons(new String[]{"Pause", "Main Menu"});
            initPanel();
            repaint();
            revalidate();

        }
        else {
            score = numberOfLives*numOfPassedLevels*10000/(restartsCounter+allSteps+3*usedMagnets);
            JOptionPane.showMessageDialog(null, "Congratulations!\n Your Score is :  " + score);
            MainWindow.menus[MainWindow.Menus.MainMenu.index]=new MainMenu(mainWindow);
            MainWindow.switchMenus(MainWindow.Menus.GameMenu,mainWindow);
        }
   }

    /**
     * Pauzuje lub wznawia rozgrywke w zaleznosci od obecnego stanu, wywoluje metode w obiekcie klasy Level odpowiednia metode
     * @param level poziom ktory ma zostac zapauzowany lub wznowiony
     */
    private void pause(Level level){
        if(pauseButtonPressed) {
            level.resume();
            pauseButtonPressed = false;
            this.requestFocus();
        }
        else {
            level.pause();
            pauseButtonPressed = true;
        }
    }

    /**
     * Resetuje licznik
     */
//    private void resetTimer() {
//        timer.cancel();
//        timer.purge();
//    }

}