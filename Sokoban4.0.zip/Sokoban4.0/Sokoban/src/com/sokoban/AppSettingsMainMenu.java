package com.sokoban;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AppSettingsMainMenu {
    static final String config_main_menu="src/com/sokoban/config/config_main_menu.txt";
    static Integer xSize;
    static Integer ySize;

    private static AppSettingsMainMenu single_instance = null;
    private AppSettingsMainMenu(){ load();}
    public static AppSettingsMainMenu getInstance()
    {
        if (single_instance == null)
            single_instance = new AppSettingsMainMenu();

        return single_instance;
    }

    public void load(){
        load_config();
    }

    private void load_config(){
        List<String> list = new ArrayList<String>();
        try{
            BufferedReader bufferedReader=new BufferedReader(new FileReader(config_main_menu));
            String line=bufferedReader.readLine();
            do {
                list.add(line);
                line= bufferedReader.readLine();
            }while(line!=null);
            save_config(list);
            bufferedReader.close();
        }catch (FileNotFoundException e){
            System.out.println("File not found");
            e.printStackTrace();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    private void save_config(List<String> list){
        xSize=Integer.parseInt(list.get(0));
        ySize=Integer.parseInt(list.get(1));
    }

    public Integer ScreenWidth(){return xSize;}
    public Integer ScreenHeight(){return ySize;}
}
