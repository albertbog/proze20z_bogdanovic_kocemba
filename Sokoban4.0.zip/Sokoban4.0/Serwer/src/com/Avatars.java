package com;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Avatars {
    static final String avatars_path="Pliki\\avatars";


    public static BufferedImage load_avatars()
    {
        int number=0;
        BufferedImage originalImage = null;
        File avtrs= new File(avatars_path);
        File[] files=avtrs.listFiles();
        String fnameNoExt = files[number].getName().substring(0, files[number].getName().lastIndexOf("."));
        try {
            originalImage = ImageIO.read(new File(avatars_path+files[number].getName()));
        } catch (IOException exception) {
            exception.printStackTrace(); }
        return originalImage;
    }
}
