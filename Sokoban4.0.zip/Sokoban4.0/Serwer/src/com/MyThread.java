package com;

import javax.imageio.ImageIO;
import java.io.*;
import java.net.Socket;

public class MyThread extends Thread
{
    private final Socket socket;
    public MyThread(Socket socket)
    {
        this.socket=socket;
    }

/*

                if (fromClient != null) {
                    System.out.println("From client: " + fromClient);
                    /*
                    if(fromClient.equals("Load_ranking") || fromClient.equals("Load_levels"))
                    {
                        String serverRespond=new ServerCommand().do_command_string(fromClient);
                        printWriter.println(serverRespond);
                        printWriter.flush();
                        System.out.println("Server respond: " + serverRespond);
                        break;
                    }
                    else if(fromClient.equals("Load_avatars") || fromClient.equals("Load_textures"))
                    {
                        ImageIcon[] serverRespond=new ServerCommand().do_command_image(fromClient);
                        printWriter.println(serverRespond);
                        printWriter.flush();
                        System.out.println("Server respond: " + serverRespond);
                        break;
                    }


                    String serverRespond=new ServerCommand().do_command_string(fromClient);
                    printWriter.println(serverRespond);
                    printWriter.flush();
                    System.out.println("Server respond: " + serverRespond);
                    break;
                }
            }
        }
        */

    @Override
    public void run() {
        try {
            while (true) {
                //Thread.sleep(10);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String fromClient = bufferedReader.readLine();
                /*
                if(fromClient.equals("Load_textures") || fromClient.equals("Load_avatars"))
                {
                    byte[] imageInByte;
                    System.out.println("From client: " + fromClient);
                    DataInputStream in = new DataInputStream (socket.getInputStream());
                    DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                    out.flush();
                    boolean cc = ImageIO.write(ServerCommand.do_command_image(fromClient),"JPG",socket.getOutputStream());
                    out.flush();
                    in.close();
                    out.close();
                    /*
                    ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();
                    String[] array=fromClient.split(" ");
                    ImageIO.write(ServerCommand.do_command_image(array[0], Integer.parseInt(array[1])), "jpg", byteArrayOutputStream);
                    byteArrayOutputStream.flush();
                    imageInByte=byteArrayOutputStream.toByteArray();
                    byteArrayOutputStream.close();

                    //String[] array=fromClient.split(" ");
                    //ImageIO.write(ServerCommand.do_command_image(array[0], Integer.parseInt(array[1])), "jpg", socket.getOutputStream());
                    break;
                }
            */
               if(fromClient!=null) {
                    PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
                    System.out.println("From client: " + fromClient);
                    String serverRespond = ServerCommand.do_command_string(fromClient);
                    printWriter.println(serverRespond);
                    printWriter.flush();
                    System.out.println("Server respond: " + serverRespond);
                    printWriter.close();
                    break;
                }
            }
        } catch (IOException exception) {
            System.out.println("Sorry! We could not do command!");
            System.err.println(exception);
        }
    }

}
