package com;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Ranking {

    static final String Ranking_path="Pliki\\Ranking.txt";
    static String list;


    public static String load_ranking()
    {
        try {
            list=new String();
            BufferedReader File = new BufferedReader(new FileReader(Ranking_path));
            String line=File.readLine();
            do {
                list=list+line+"/";
                line=File.readLine();
            }while(line!=null);
            File.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        return list;
    }
}
