
package com.sokoban;


/**Klasa uruchomienia Aplikacji*/
public class Main {

    public static void main(String[] args){
        new MainWindow();
    }
}
